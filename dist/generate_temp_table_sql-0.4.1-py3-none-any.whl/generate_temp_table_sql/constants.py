class Constants:

    DEFAULT_TABLE_NAME = 'table_name'
    DEFAULT_COLUMN_TYPE = 'TEXT'